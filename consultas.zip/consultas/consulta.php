<?php

require_once("../includes/nav_menu.php");

?>

      </div>
      <div class="navigation-background"></div>
    </div>

    <div class="app-content content">
      <div class="content-wrapper">
        <div class="content-wrapper-before"></div>
        <div class="content-header row">
        </div>
        <div class="content-body">        
      <input id="ip_cliente" name="ip_cliente" type="hidden" value='<?php echo $_SERVER["REMOTE_ADDR"] ?>'>
<div class="row">
    <div class="col-md-9" style="margin: 0 auto;">
        <div class="card bg-white mt-4">
        <div class="card-header mb-0">
         <h5 class="text-center mb-2"><i class="ft-search"></i> CONSULTA CPF</h5>                 
                    <input class="form-control mb-1" id="doc" type="text" placeholder="CPF">
                    <button class="btn btn-bg-gradient-x-purple-blue btn-block text-white consultar">CONSULTAR</button>
                </div>
               </div>
            </div>           
    <div class="col-md-9" style="margin: 0 auto;">
        <div class="card">
            <div class="card-body">
                <h5 class="text-center"><i class="ft-search"></i> RESULTADO</h5><hr>
   <div id="resultado" class="mb-0"></div>
                   </div>                                        
                </div>
            </div>
        </div>
    </div>

</div>
    <script src="../theme-assets/vendors/js/vendors.min.js" type="text/javascript"></script>
    <script src="../theme-assets/js/core/app-menu-lite.js" type="text/javascript"></script>
    <script src="../theme-assets/js/core/app-lite.js" type="text/javascript"></script>
    <script src="../theme-assets/js/scripts/pages/dashboard-lite.js" type="text/javascript"></script>
    <script src="https://code.jquery.com/jquery-2.1.3.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert-dev.js"></script>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/sweetalert/1.1.3/sweetalert.css">

<script type="text/javascript">

$('.consultar').click(function(){
	$(this).text('Consultando...');
	var doc = $('#doc').val().trim();
	
	$.ajax({
		url: 'consultas/completa.php?doc=' + doc,
		type: 'GET',
		success: function(resultado){
			$('#resultado').html(resultado);
			$('.consultar').text('Consultar');
		},
		error: function(error){
			alert(error);
		}
	}); //ajax
});

</script>
  </body>
</html>