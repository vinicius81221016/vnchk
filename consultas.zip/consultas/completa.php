<?php

session_start();
error_reporting(0);
set_time_limit(0);

//print_r($_SESSION); 

if($_SESSION["saldo"] <= 1){
die("<div class='text-center text-danger'><b>CREDITOS INSUFICIENTES</b></div>");
}

$doc = $_GET["doc"];

if(empty($doc)){
	die("<div class='text-center text-danger'><b>INFORME UM CPF</b></div>");
}

$cpf = trim(str_replace(["-","."], "", $doc));

if(!is_numeric($cpf) or strlen($cpf) <> 11){
die("<div class='text-center text-danger'><b>CPF INVÁLIDO</b></div>");
}

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://191.252.153.147/MasterTarget/teste.php?token=HhH2BXDKTSyNwhaZzyCh&cpf=$cpf");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$buscar = json_decode(curl_exec($ch), true);

$nomePrimeiro = $buscar["result"]["0"]["pessoa"]["cadastral"]["nomePrimeiro"];
$nomeMeio = $buscar["result"]["0"]["pessoa"]["cadastral"]["nomeMeio"];
$nomeUltimo = $buscar["result"]["0"]["pessoa"]["cadastral"]["nomeUltimo"];
$sexo = $buscar["result"]["0"]["pessoa"]["cadastral"]["sexo"];
$dataNascimento = $buscar["result"]["0"]["pessoa"]["cadastral"]["dataNascimento"];
$statusReceitaFederal = $buscar["result"]["0"]["pessoa"]["cadastral"]["statusReceitaFederal"];
$rgNumero = $buscar["result"]["0"]["pessoa"]["cadastral"]["rgNumero"];
$rgOrgaoEmissor = $buscar["result"]["0"]["pessoa"]["cadastral"]["rgOrgaoEmissor"];
$rgUf = $buscar["result"]["0"]["pessoa"]["cadastral"]["rgUf"];
$tituloEleitoral = $buscar["result"]["0"]["pessoa"]["cadastral"]["tituloEleitoral"];
$obito = $buscar["result"]["0"]["pessoa"]["cadastral"]["obito"]; //retorna true ou false (true = morto, false = vivo)
$estadoCivil = $buscar["result"]["0"]["pessoa"]["cadastral"]["estadoCivil"];
$maeCPF = $buscar["result"]["0"]["pessoa"]["cadastral"]["maeCPF"];
$maeNomePrimeiro = $buscar["result"]["0"]["pessoa"]["cadastral"]["maeNomePrimeiro"];
$maeNomeMeio = $buscar["result"]["0"]["pessoa"]["cadastral"]["maeNomeMeio"];
$maeNomeUltimo = $buscar["result"]["0"]["pessoa"]["cadastral"]["maeNomeUltimo"];
$escolaridade = $buscar["result"]["0"]["pessoa"]["cadastral"]["escolaridade"];
$cns = $buscar["result"]["0"]["pessoa"]["cadastral"]["cns"];

$endereco = $buscar["result"]["0"]["pessoa"]["contato"]["endereco"];

$enderecos = "";
foreach($endereco as $key => $value){
$tipoLogradouro = $value["tipoLogradouro"];
$logradouro = $value["logradouro"];
$numero = $value["numero"];
$complemento = $value["complemento"];
$bairro = $value["bairro"];
$cidade = $value["cidade"];
$uf = $value["uf"];
$cep = $value["cep"];
$num = $key +1;
$enderecos .= "
<b>ENDEREÇO $num :</b><br>\n
<b>TIPO:</b> $tipoLogradouro <br>\n
<b>LOGRADOURO:</b> $logradouro <br>\n
<b>NUMERO:</b> $numero <br>\n
<b>COMPLEMENTO:</b> $complemento <br>\n
<b>BAIRRO:</b> $bairro <br>\n
<b>CIDADE:</b> $cidade <br>\n
<b>ESTADO:</b> $uf <br>\n
<b>CEP:</b> $cep <br>\n";
}

$listaEmail = "";
$emails = $buscar["result"]["0"]["pessoa"]["contato"]["email"];

foreach($emails as $key => $value){
$email = $value["email"];
$num = $key +1;
$listaEmail .= "<b>Email $num:</b> $email <br>\n";
}

$listaTell = "";
$tells = $buscar["result"]["0"]["pessoa"]["contato"]["telefone"];

foreach($tells as $key => $value){
$ddd = $value["ddd"];
$numero = $value["numero"];
$num = $key +1;
$listaTell .= "<b>Telefone $num:</b> $ddd$numero<br>\n";
}

$listaParentes = "";
$parentes = $buscar["result"]["0"]["pessoa"]["vinculo"]["parentesco"];

foreach($parentes as $key => $value){
$pcpf = $value["cpf"];
$nomeCompleto = $value["nomeCompleto"];
$grauDeParentesco = $value["grauDeParentesco"];
$num = $key +1;
$listaParentes .= "<b>Parente $num:</b> <br>\n
<b>NOME:</b> $nomeCompleto<br>\n
<b>CPF:</b> $pcpf<br>\n
<b>TIPO:</b> $grauDeParentesco<br>\n";
}

$listaVizinhos = "";
$vizinhos = $buscar["result"]["0"]["pessoa"]["vinculo"]["vizinho"];

foreach($vizinhos as $key => $value){
$vcpf = $value["cpf"];
$vnomePrimeiro = $value["nomePrimeiro"];
$vnomeMeio = $value["nomeMeio"];
$vnomeUltimo = $value["nomeUltimo"];
$num = $key +1;
$listaVizinhos .= "<b>VIZINHO $num :</b><br>\n
<b>CPF:</b> $vcpf<br>\n
<b>NOME:</b> $vnomePrimeiro $vnomeMeio $vnomeUltimo<br>\n";
}

$profissao = $buscar["result"]["0"]["pessoa"]["socioDemografico"]["profissao"];
$rendaPresumida = $buscar["result"]["0"]["pessoa"]["socioDemografico"]["rendaPresumida"];

if($obito){
	$obito = "Sim";
}else{
	$obito = "Nao";
}


if(!empty($nomePrimeiro)){

$usuario = $_SESSION["usuario"];
$count = $_SESSION["consultados"];
$total = $count +1;
$_SESSION["consultados"] = $total;
$saldo = $_SESSION["saldo"];
$newsaldo = $saldo -1;
$_SESSION["saldo"] = $newsaldo;

include("../../includes/conexao.php");
$sql = "update usuario set consultados='$total', saldo='$newsaldo' where usuario='$usuario'";
mysqli_query($conexao, $sql);

echo 
"<b>NOME:</b> $nomePrimeiro $nomeMeio $nomeUltimo<br>\n
<b>CPF:</b> $cpf<br>\n
<b>NOME MAE:</b> $maeNomePrimeiro $maeNomeMeio $maeNomeUltimo<br>\n
<b>CPF MAE:</b> $maeCPF<br>\n
<b>SEXO:</b> $sexo<br>\n
<b> DATA NASCIMENTO:</b> $dataNascimento<br>\n
<b>SITUACAO:</b> $statusReceitaFederal<br>\n
<b>RG:</b> $rgNumero<br>\n
<b>ORGAO EMISSOR:</b> $rgOrgaoEmissor<br>\n
<b>UF RG:</b> $rgUf<br>\n
<b>OBITO:</b> $obito<br>\n
<b>TITULO:</b> $tituloEleitoral<br>\n
<b>ETADO CIVIL:</b> $estadoCivil<br>\n
<b>ESCOLARIDADE:</b> $escolaridade<br>\n
$enderecos
$listaTell
$listaEmail
$listaVizinhos
$listaParentes
<b>PROFISSAO:</b> $profissao <br>\n
<b>RENDA PRESUMIDA:</b> $rendaPresumida<br>\n
";
exit();
}else{
die("<div class='text-center text-danger'><b>DADOS NÃO ENCONTRADOS</b></div>");
}

?>